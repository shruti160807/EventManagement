<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Document</title>
    <link
      rel="stylesheet"
      href="https://cdn.jsdelivr.net/npm/bootstrap@4.0.0/dist/css/bootstrap.min.css"
    />
    <link
      rel="stylesheet"
      href="https://fonts.googleapis.com/css?family=Sofia"
    />
    <link rel="stylesheet" href="styles.css" />
    <script src="https://code.jquery.com/jquery-3.6.4.min.js"></script>
<style>
    .row{
        margin:10px;
    }
    div{
        font-weight:bold;
        font-size:15px;
    }
</style>
</head>
<body>
    <div class="container-fluid">
    <div
        class="row"
        style="
          background-color: rgb(226, 178, 207);
          position: sticky;
          top: 0;
          z-index: 1;
        "
      >
        <div class="col-2"><a href="index.php"><img src="logo.PNG" alt="" /></a></div>
        <div class="col-2" style="margin-top: 20px">
          <h2 style="font-family: Sofia, sans-serif">LVE Events</h2>
        </div>
        <div class="col-6" style="text-align: right"></div>
        <div class="col-2">
          <button class="btn btn-danger" style="margin-top: 20px">Login</button>
        </div>
      </div>

    </div>
    <div class="container text-center mt-4"style="width:50%; border:1px solid black ; border-radius:5px">
        <div class="row">
            <div class="col text-center font-weight-bold" >
                Sign Up Form
            </div>
        </div>
        <div class="row"><div class="col">
            Username
        </div>
        <div class="col"><input type="text" class="form-control" id="username"></div>
    </div>
    
    <div class="row"><div class="col">
            Password
        </div>
        <div class="col"><input type="password" class="form-control" id="password"></div>
    </div>
    
    <div class="row"><div class="col">
            Phone No
        </div>
        <div class="col"><input type="text" class="form-control" id="phone"></div>
    </div>

    
    <div class="row mb-4"><div class="col">
            <button class="btn btn-outline-success" onclick="singUp();">Sign Up</button>
        </div>
    </div>

    </div>
</body>

<script>
    function singUp(){
        if(username.value!="" && password.value!="" && phone.value!=""){

            $.ajax({
        url: 'includes/get_result.php',
        type: 'POST',
        data:  {"REQUEST_TYPE":"SIGN_UP","USERNAME":username.value,"PASSWORD":password.value,"PHONE":phone.value},
        success: function(response){  
          console.log(response);
          if(response==1){
          toastr.success("User Registration Successful, Please Login");
          }
          else{
          toastr.error("Something went wrong");
          }
          
         username.value="";
         password.value="";
         phone.value="";
         }
        });

        }else{

            toastr.error("Please Fill All Fields");
        }
    }
</script>


  <!--Toastr (Notification Library) -->
  <script src="https://cdnjs.cloudflare.com/ajax/libs/toastr.js/latest/js/toastr.min.js"></script>
  <link
    rel="stylesheet"
    href="https://cdnjs.cloudflare.com/ajax/libs/toastr.js/latest/css/toastr.min.css"
  />

</html>