

<!DOCTYPE html>
<html lang="en">
  <head>
    <meta charset="UTF-8" />
    <meta http-equiv="X-UA-Compatible" content="IE=edge" />
    <meta name="viewport" content="width=device-width, initial-scale=1.0" />
    <title>Document</title>
    <script src="js/functions.js"></script>

    <script src="https://code.jquery.com/jquery-3.2.1.slim.min.js"></script>
    <script src="https://code.jquery.com/jquery-3.2.1.min.js"></script>
    <link
      rel="stylesheet"
      href="https://cdn.jsdelivr.net/npm/bootstrap@4.0.0/dist/css/bootstrap.min.css"
    />
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@4.0.0/dist/js/bootstrap.min.js"></script>

    <link
      rel="stylesheet"
      href="https://fonts.googleapis.com/css?family=Sofia"
    />

    <link rel="stylesheet" href="styles.css" />

  </head>
  <body  id="mainBody">
     <div class="container-fluid">
     <!--Nav Bar-->
     <?php
     require_once('layouts/navbar.php');
     ?>

      <div class="row rowTop">
        <div class="col">
          <h3>Polular Wedding Halls</h3>
        </div>
      </div>

  </body>

  <script>

   

     $( document ).ready(function() {
  
      $.ajax({
            url: 'includes/get_result.php',
            type: 'POST',
            data:  {"REQUEST_TYPE":"GET_HALLS"},
            success: function(response){        
          
             bodyLoaded(response) ;
       }
      });

});

    function bodyLoaded(jsonString) {
      //JSON Parsing
  /*    var jsonString=`{
"username":"sachin",
"age":28,
"isAdult":true,
"marks":[58,20,52,85],
"subjects":{
"id":1,
"name":"computer science",
"weightage":80,
"grade":["A","A++","B","B++"]
}
}`;

console.log(jsonString);
var jobj=JSON.parse(jsonString);

for(var i=0;i<jobj.subjects.grade.length;i++){
  console.log(jobj.subjects.grade[i]);
}
*/

   console.log(jsonString);
var jobj= JSON.parse(jsonString);
var imgArray =jobj.imgArray;
var descArray = jobj.descArray;
var idsArray = jobj.ids;

      var hallsDiv = document.createElement("div");
      hallsDiv.style.display = "flex";
      hallsDiv.style.flexWrap = "wrap";
      for (var i = 0; i < imgArray.length; i++) {
        var mainImgDiv = document.createElement("div");
        mainImgDiv.style.margin = "18px";
        var mainImg = document.createElement("img");
        mainImg.classList.add("imgSize");
        mainImg.src = "images/"+imgArray[i];
        mainImg.style = "height:200px ; wedth:300px";
        mainImgDiv.appendChild(mainImg);
        mainBody.appendChild(mainImgDiv);

        var discDiv = document.createElement("div");
        discDiv.style.display = "flex";

        var halldesc = document.createElement("div");
        var textabouthall = document.createElement("p");
        textabouthall.innerHTML = descArray[i];
        halldesc.appendChild(textabouthall);
        discDiv.appendChild(halldesc);

        var buttonDiv = document.createElement("div");
        var contactBtn = document.createElement("button");
        contactBtn.style.marginTop="25px";
        contactBtn.style.marginLeft="35px";
        
        contactBtn.id = idsArray[i];
        contactBtn.innerHTML = "contact now";
        contactBtn.classList.add("btn");
        contactBtn.classList.add("btn-success");
        contactBtn.addEventListener("click", contactNowClicked);
        buttonDiv.appendChild(contactBtn);
        discDiv.appendChild(buttonDiv);

        mainImgDiv.appendChild(discDiv);
        hallsDiv.appendChild(mainImgDiv);
      }
      mainBody.appendChild(hallsDiv);
    }
    function contactNowClicked(currentId) {
      window.location.href = "halldescription.php?hallid=" + this.id;
      console.log(this.id);
    }

  </script>

  


</html>
