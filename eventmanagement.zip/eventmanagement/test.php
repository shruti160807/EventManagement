<?php
/*PHP supports Super Global Variables which can be used through out the php pages
eg: $_GET, $_POST, $_SESSION ...
All super global variables are of type Associative Array
To print array in php we use print_r() method
Associative array contains key value pair(uname, pass)
Index array contains indexes (0,1,2)
*/
$uname=$_POST['uname'];
$pass=$_POST['pass'];
print_r($uname);
if($uname=="admin" && $pass=="asd"){
echo "<h1 style='color:aqua'>Authentication Successfull</h1>";
}else{
    echo "<h1 style='color:red'>Authentication Failed</h1>";
}

?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Document</title>
    <input type="text" id="uname" value="<?php echo $uname;?>" hidden>
    <script>
        console.log(uname.value); 
    </script>
</head>
<body>
    
</body>
</html>