<!DOCTYPE html>
<html lang="en">
  <head>
    <meta charset="UTF-8" />
    <meta http-equiv="X-UA-Compatible" content="IE=edge" />
    <meta name="viewport" content="width=device-width, initial-scale=1.0" />
    <title>Confirm Booking</title>

    
    <script src="js/functions.js"></script>
    <script src="https://code.jquery.com/jquery-3.2.1.slim.min.js"></script>
    <script src="https://code.jquery.com/jquery-3.2.1.min.js"></script>
    <link
      rel="stylesheet"
      href="https://cdn.jsdelivr.net/npm/bootstrap@4.0.0/dist/css/bootstrap.min.css"
    />
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@4.0.0/dist/js/bootstrap.min.js"></script>

    <link
      rel="stylesheet"
      href="https://fonts.googleapis.com/css?family=Sofia"
    />

    <link rel="stylesheet" href="styles.css" />
  </head>
  <body  id="mainBody">
    <div class="container-fluid">
        <!--Nav Bar-->
        <?php
     require_once('layouts/navbar.php');
     ?>

    </div>

    
  </body>
  <script>
var jobj="";
  $( document ).ready(function() {
    var hallid=getHallId();
  $.ajax({
        url: 'includes/get_result.php',
        type: 'POST',
        data:  {"REQUEST_TYPE":"GET_HALL_BOOKING_STATUS","HALLID":hallid},
        success: function(response){  
          console.log(response);
           jobj=JSON.parse(response);
 
          bodyLoaded(jobj);
   }
  });

});

function getHallId(){
      const queryString = window.location.search; //returns part after ?
      const urlParams = new URLSearchParams(queryString); //returns object that contains keys and valus
      hallid = urlParams.get("hallid"); //returns value of key
      return hallid;
    }



    function bodyLoaded(jobj) {
      console.log(jobj);
      //heading
      var head = document.createElement("h3");
      head.innerHTML = "Confirm Booking";
      head.style = "text-align: center; color: red";
      mainBody.appendChild(head);

      //mainContainer
      var mainContainer = document.createElement("div");
      mainContainer.classList.add("container");
      mainContainer.style =
        "margin-top: 25px;border: 2px solid rgb(250, 155, 230);border-radius: 15px;";

      //row
      var mainRow = document.createElement("div");
      mainRow.classList.add("row");
      //image
      var imgCol = document.createElement("div");
      imgCol.classList.add("col-4");
      var mainImg = document.createElement("img");
      mainImg.src = "images/"+jobj.hallimage;
      mainImg.style = "width:400px; height:300px; padding: 25px";
      imgCol.appendChild(mainImg);
      mainRow.appendChild(imgCol);

      //desc
      var emptyCol = document.createElement("div");
      emptyCol.classList.add("col-1");
      mainRow.appendChild(emptyCol);

      var descDiv = document.createElement("div");
      descDiv.classList.add("col-7");

      var titleDiv = document.createElement("div");
      titleDiv.classList.add("mt-4");

      var hallTitle = document.createElement("h2");
      hallTitle.style = "font-weight: bold";
      hallTitle.innerHTML = jobj.hallName;
      var hallAdd = document.createElement("p");
      hallAdd.innerHTML = jobj.hallAddress;
      var hallPrice = document.createElement("h4");
      hallPrice.innerHTML = "Rs. "+jobj.price +"/-";
      hallPrice.style = "color: red; font-size: 20px; font-weight: bold";

      titleDiv.appendChild(hallTitle);
      titleDiv.appendChild(hallAdd);
      titleDiv.appendChild(hallPrice);
      descDiv.appendChild(titleDiv);

      var dateDiv = document.createElement("div");
      dateDiv.classList.add("flex-container");
      var dateItemDiv = document.createElement("div");
      dateItemDiv.classList.add("flex-items");
      var dateParaDiv = document.createElement("p");
      dateParaDiv.innerHTML = "Select Event Date";
      var eventDate = document.createElement("input");
      eventDate.type = "date";
      eventDate.id = "eventDate";

      dateItemDiv.appendChild(dateParaDiv);
      dateItemDiv.appendChild(eventDate);
      dateDiv.appendChild(dateItemDiv);
      descDiv.appendChild(dateDiv);

      var buttonItemDiv = document.createElement("div");
      buttonItemDiv.classList.add("flex-items");

      var statusButton = document.createElement("button");
      statusButton.classList.add("btn");
      statusButton.classList.add("btn-primary");
      statusButton.style = "margin-top: 25px";
      statusButton.innerHTML = "Check Availability";
      statusButton.addEventListener("click", checkAvailiblity);

      buttonItemDiv.appendChild(statusButton);
      dateDiv.appendChild(buttonItemDiv);
      descDiv.appendChild(dateDiv);
      mainRow.appendChild(descDiv);
      mainContainer.appendChild(mainRow);

      var secondRow = document.createElement("div");
      secondRow.classList.add("row");
      secondRow.classList.add("mb-4");

      var secondButtonDiv = document.createElement("div");
      secondButtonDiv.classList.add("col");
      secondButtonDiv.classList.add("text-center");

      var confirmButton = document.createElement("button");
      confirmButton.classList.add("btn");
      confirmButton.classList.add("btn-success");
      confirmButton.disabled = true;
      confirmButton.id = "btnConfirm";
      confirmButton.dataTarget = "confirmationModal";
      confirmButton.innerHTML = "Confirm Booking";
      confirmButton.addEventListener("click", makePayment);

      secondButtonDiv.appendChild(confirmButton);
      secondRow.appendChild(secondButtonDiv);
      mainContainer.appendChild(secondRow);

      mainBody.appendChild(mainContainer);
    }

    function checkAvailiblity() {
      console.log(eventDate.value);
      if (eventDate.value == "") {
        //invalid date
        toastr.warning("Please select valid event date");
      } else {
        //valid date
        
        if (jobj.bookingDates.includes(eventDate.value)) {
        
          btnConfirm.disabled = true;
          toastr.error("Booking Already Full");
        } else {
            //check available date
            btnConfirm.disabled = false;
          toastr.success("Booking Available");
        }
      }
    }

    function makePayment() {
      //  window.location.replace("home.html");

      $("#confirmationModal").modal("toggle");
    }

    function confirmPayment() {
      window.location.replace("index.php");
    }

    function editMemo(element) {
      console.log(element);
    }
  </script>

  <div class="modal" tabindex="-1" role="dialog" id="confirmationModal">
    <div class="modal-dialog" role="document">
      <div class="modal-content">
        <div class="modal-header">
          <h5 class="modal-title" style="color: red">Confirm Booking</h5>
          <button
            type="button"
            class="close"
            data-dismiss="modal"
            aria-label="Close"
          >
            <span aria-hidden="true">&times;</span>
          </button>
        </div>
        <div class="modal-body">
          <p>Do You want to make Payment?</p>
        </div>
        <div class="modal-footer">
          <button
            type="button"
            class="btn btn-success"
            onclick="confirmPayment();"
          >
            Make Payment
          </button>
          <button type="button" class="btn btn-danger" data-dismiss="modal">
            Cancel
          </button>
        </div>
      </div>
    </div>
  </div>
  <!--Toastr (Notification Library) -->
  <script src="https://cdnjs.cloudflare.com/ajax/libs/toastr.js/latest/js/toastr.min.js"></script>
  <link
    rel="stylesheet"
    href="https://cdnjs.cloudflare.com/ajax/libs/toastr.js/latest/css/toastr.min.css"
  />



</html>
