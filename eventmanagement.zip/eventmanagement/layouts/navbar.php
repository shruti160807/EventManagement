<div
        class="row"
        style="
          background-color: rgb(226, 178, 207);
          position: sticky;
          top: 0;
          z-index: 1;
        "
      >
        <div class="col-2"><a href="index.php"><img src="logo.PNG" alt="" /></a></div>
        <div class="col-2" style="margin-top: 20px">
          <h2 style="font-family: Sofia, sans-serif">LVE Events</h2>
        </div>
        <div class="col-5" style="text-align: right"></div>
        <div class="col-3">
          <div class='mt-4'>
        <?php 
                session_start(); 
              if(isset($_SESSION['login']) && $_SESSION['login']==true){
               $username=$_SESSION['user']['username'];
               $icon=$_SESSION['user']['icon'];
                echo " <img src='images/$icon' style='width:20px;height:20px' > Welcome  $username <button style='margin-left:30px; ' class='btn btn-outline-danger' onclick='logout();'>Logout </button>" ;
      }else{
        echo  "<button class='btn btn-danger'  data-toggle='modal' data-target='#loginModal' >Login</button>";   
      }
?>
</div>
        
        </div>
      </div>



      
<!-- Login Modal -->
<div class="modal" tabindex="-1" role="dialog" id="loginModal">
  <div class="modal-dialog" role="document">
    <div class="modal-content">
      <div class="modal-header">
        <h5 class="modal-title">Login</h5>
        <button type="button" class="close" data-dismiss="modal" aria-label="Close">
          <span aria-hidden="true">&times;</span>
        </button>
      </div>
      <div class="modal-body">
        <div class="container">
          <div class="row"><div class="col">
            Username
          </div>
        <div class="col">
          <input type="text" class="form-control" id="username">
        </div>
      </div>
      <div class="row mt-4"><div class="col">
            Password
          </div>
        <div class="col">
          <input type="password" class="form-control" id="password">
        </div>
      </div>


        </div>
      </div>
      <div class=" text-center mb-4">
        <button type="button" class="btn btn-primary" onclick="login();">Login</button> <br> 
        <span > Don't have Account? <a href="signup.php"> Sign Up</a> </span>
      </div>
    </div>
  </div>
</div>



  <!--Toastr (Notification Library) -->
  <script src="https://cdnjs.cloudflare.com/ajax/libs/toastr.js/latest/js/toastr.min.js"></script>
  <link
    rel="stylesheet"
    href="https://cdnjs.cloudflare.com/ajax/libs/toastr.js/latest/css/toastr.min.css"
  />
