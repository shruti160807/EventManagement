<!DOCTYPE html>
<html lang="en">
  <head>
    <meta charset="UTF-8" />
    <meta http-equiv="X-UA-Compatible" content="IE=edge" />
    <meta name="viewport" content="width=device-width, initial-scale=1.0" />
    <title>Document</title>
    <link
      rel="stylesheet"
      href="https://cdn.jsdelivr.net/npm/bootstrap@4.0.0/dist/css/bootstrap.min.css"
    />
  </head>
  <body onload="bodyLoaded();" id="mainBody"></body>
  <script>
    function bodyLoaded() {
      /*  var firsth1 = document.createElement("h1");
      firsth1.innerHTML = "This is New Heading";
      firsth1.style.color = "red";
      mainBody.appendChild(firsth1);
      var ipname = document.createElement("input");
      ipname.value = "Sachin";
      ipname.disabled = true;
      mainBody.appendChild(ipname);*/

      //image
      var mainDiv = document.createElement("div");
      var hallimg = document.createElement("img");
      hallimg.src = "wed_hall_1.jpg";
      mainDiv.appendChild(hallimg);

      //description
      var descDiv = document.createElement("div");
      var textDiv = document.createElement("div");
      var hallText = document.createElement("p");
      hallText.innerHTML = "Lotus Inn 4.5 stars ";
      textDiv.appendChild(hallText);
      descDiv.appendChild(textDiv);
      mainDiv.appendChild(descDiv);
      mainBody.appendChild(mainDiv);
    }
  </script>
</html>
