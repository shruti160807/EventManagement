<?php
require_once('dbconnect.php');
session_start();
//testing();

function  getHalls(){
    global $conn;
    $hallImgs=array();
    $hallIds=array();
    $hallDesc=array();
    $stmt= $conn->prepare("SELECT *  from halls");
    if($stmt){
        if($stmt->execute()){
            $result= $stmt->get_result();
            while($row=$result->fetch_assoc()){
              array_push($hallIds,$row['id']);
              array_push($hallImgs,$row['image']);
          
              $halldescription= $row['name'] . "<br>" . $row['mobile'];
              array_push($hallDesc,$halldescription);
            }
            $finalArray=array("imgArray"=>$hallImgs,"descArray"=>$hallDesc,"ids"=>$hallIds);
            return $finalArray;
        }else{
          echo "Execute Error";
        }
    }else{
      echo "Prepare Error";
    }

   }
   
   
   function getHallDesc($hallid){

       $hall=getHall($hallid);
       
       $hallName=$hall['name'];
       $hallAddress=$hall['address'];
      
         $amiIconsArr=getAminities($hallid)['icons'];
         $amiDescArr=getAminities($hallid)['desc'];

         $subImgArr= getSmallImages($hallid);

       $ratingavg=getRatings($hallid);
       $ratingText="";
       for($i=0;$i<$ratingavg;$i++){
        $ratingText=$ratingText."⭐";
       }
       $ratingStarsArr=$ratingText."($ratingavg)";
  
         $usernameArr=getReviews($hallid)['usernameArr'];
         $reviewsArr=getReviews($hallid)['reviewsArr'];

         $finalArray=array("hallPrice"=> $hall['price'],"hallMainImage"=>$hall['image'],  "amiIconsArr"=>$amiIconsArr,"amiDescArr"=>$amiDescArr,"subImgArr"=>$subImgArr,"ratingStarsArr"=>$ratingStarsArr,"usernameArr"=>$usernameArr,"reviewsArr"=>$reviewsArr,"hallDName"=>$hallName,"hallDAddress"=>$hallAddress);
         return $finalArray;
   
   }
   
   function getHallBookingStatus($hallid){
    $hall=getHall($hallid);

     $hallName=$hall['name'];
     $hallAddress=$hall['address'];
     $price=$hall['price'];
     $hallimage=$hall['image'];
     $bookingDates=getBookingDate($hallid);

      
   
    $finalArray=array("hallName"=>$hallName,"hallAddress"=>$hallAddress,"price"=>$price,"bookingDates"=>$bookingDates,"hallimage"=>$hallimage);
    return $finalArray;
   }
   

   function getSmallImages($hallid){
    global $conn;
    $subImgArr=array();
   $stmt=$conn->prepare("SELECT simage FROM `smallimages` WHERE hallid=?");
  if($stmt){
    $stmt->bind_param('i',$hallid);
    if($stmt->execute()){
      $result= $stmt->get_result();
     while($row= $result->fetch_assoc()){
       array_push($subImgArr,$row['simage']);
     }
     return $subImgArr;

    }else{
      echo "Execute Error";
    }
  }else{
    echo "Prepare Error";
  }
   }

   function getHall($hallid){
    global $conn;
   $stmt=$conn->prepare("SELECT * FROM `halls` WHERE id=?");
  if($stmt){
    $stmt->bind_param('i',$hallid);
    if($stmt->execute()){
      $result= $stmt->get_result();
      $row= $result->fetch_assoc();
      return $row;
    }else{
      echo "Execute Error";
    }
  }else{
    echo "Prepare Error";
  }
   }

   
   function getAminities($hallid){
    global $conn;
    $aminityIcons=array();
    $aminityDesc=array();
   $stmt=$conn->prepare("SELECT aminities.* FROM `hallaminities` INNER JOIN halls ON hallaminities.hallid=halls.id INNER JOIN aminities ON hallaminities.amitityid=aminities.id WHERE halls.id=?");
  if($stmt){
    $stmt->bind_param('i',$hallid);
    if($stmt->execute()){
      $result= $stmt->get_result();
      while($row= $result->fetch_assoc()){
        array_push($aminityIcons,$row['image']);
        array_push($aminityDesc,$row['desc']);
      }
      $finalArray=array("icons"=>$aminityIcons,"desc"=>$aminityDesc);
      return $finalArray;
    }else{
      echo "Execute Error";
    }
  }else{
    echo "Prepare Error";
  }
  }

   function getReviews($hallid){
    global $conn;
    $usernameArr = array();
    $reviewsArr = array();      
   $stmt=$conn->prepare("SELECT * FROM `reviews` INNER JOIN users ON reviews.userid=users.id WHERE reviews.hallid=?");
  if($stmt){
    $stmt->bind_param('i',$hallid);
    if($stmt->execute()){
      $result= $stmt->get_result();
      while($row= $result->fetch_assoc()){
        array_push($usernameArr,$row['username']);
        array_push($reviewsArr,$row['review']);
      }
      $finalArray=array("usernameArr"=>$usernameArr,"reviewsArr"=>$reviewsArr);
      return $finalArray;
    }else{
      echo "Execute Error";
    }
  }else{
    echo "Prepare Error";
  }
  }
  function getRatings($hallid){
    global $conn;     
   $stmt=$conn->prepare("SELECT AVG(rating) as ratingavg FROM `reviews` WHERE hallid=?");
  if($stmt){
    $stmt->bind_param('i',$hallid);
    if($stmt->execute()){
      $result= $stmt->get_result();
      $row= $result->fetch_assoc();
      
      return $row['ratingavg'];
    }else{
      echo "Execute Error";
    }
  }else{
    echo "Prepare Error";
  }
  }



  function getBookingDate($hallid){
    global $conn;  
    $bookingDates=array();   
   $stmt=$conn->prepare("SELECT bdate FROM `bookeddates` WHERE hallid=?");
  if($stmt){
    $stmt->bind_param('i',$hallid);
    if($stmt->execute()){
      $result= $stmt->get_result();

      while($row= $result->fetch_assoc()){
        array_push($bookingDates,$row['bdate']);
      }
      
      return $bookingDates;
    }else{
      echo "Execute Error";
    }
  }else{
    echo "Prepare Error";
  }
  }


  function signUp($username,$password,$phone){
    global $conn;  
    $password=md5($password);

   $stmt=$conn->prepare("INSERT INTO users(username,password,phone) VALUES(?,?,?)");
  if($stmt){
    $stmt->bind_param('sss',$username,$password,$phone);
    if($stmt->execute()){
     

      return 1;
    }else{
      return 0;
    }
  }else{
    return 0;
  }

  }


  
  function signIn($username,$password){
    global $conn;  
    $password=md5($password);
   $stmt=$conn->prepare("SELECT COUNT(*) as usercount FROM `users` WHERE username=? AND password=?");
  if($stmt){
    $stmt->bind_param('ss',$username,$password);
    if($stmt->execute()){
      $result= $stmt->get_result();
      $row= $result->fetch_assoc();
      $usercount=$row['usercount'];
   if($usercount==1){
    $user=getUser($username);
    $_SESSION['user']= $user;
    $_SESSION['login']=true;
        return 1;
   }else{
    return 2;
   }
    }else{
      return 0;
    }
  }else{
    return 0;
  }
  }



  
  function getUser($username){
    global $conn;    
   $stmt=$conn->prepare("SELECT * FROM `users` WHERE username=?");
  if($stmt){
    $stmt->bind_param('s',$username);
    if($stmt->execute()){
      $result= $stmt->get_result();
      $row= $result->fetch_assoc(); 
      
      return $row;
    }else{
      echo "Execute Error";
    }
  }else{
    echo "Prepare Error";
  }
  }




?>