<?php
require_once('functions.php'); 

$REQUEST_TYPE=$_POST['REQUEST_TYPE'];
switch($REQUEST_TYPE){
    case "GET_HALLS":
        $halls=getHalls();
        $jsonString=json_encode($halls);
        print_r($jsonString);
    break;
    case "GET_HALL_DESC":
        $hallid=$_POST['HALL_ID'];
        $hallDesc=getHallDesc($hallid);
        $jsonString=json_encode($hallDesc);
        print_r($jsonString);
    break;  
    case "GET_HALL_BOOKING_STATUS":
      $hallid=$_POST['HALLID'];
      $hallBookingStatus=getHallBookingStatus($hallid);
      $jsonString=json_encode($hallBookingStatus);
      print_r($jsonString);
  break;

  case "SIGN_UP":
    $username= $_POST['USERNAME'];
    $password= $_POST['PASSWORD'];
    $phone=$_POST['PHONE'];
    $result=signUp($username,$password,$phone);
    print_r($result);
break;

case "SIGN_IN":
    $username= $_POST['USERNAME'];
    $password= $_POST['PASSWORD'];
    $result=signIn($username,$password);
    print_r($result);
break;


}
 

?>