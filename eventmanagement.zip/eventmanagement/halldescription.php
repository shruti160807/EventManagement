<!DOCTYPE html>
<html lang="en">
  <head>
    <meta charset="UTF-8" />
    <meta http-equiv="X-UA-Compatible" content="IE=edge" />
    <meta name="viewport" content="width=device-width, initial-scale=1.0" />
    <title>Hall Description</title>
   
    
    <script src="js/functions.js"></script>
    <script src="https://code.jquery.com/jquery-3.2.1.slim.min.js"></script>
    <script src="https://code.jquery.com/jquery-3.2.1.min.js"></script>
    <link
      rel="stylesheet"
      href="https://cdn.jsdelivr.net/npm/bootstrap@4.0.0/dist/css/bootstrap.min.css"
    />
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@4.0.0/dist/js/bootstrap.min.js"></script>

    <link
      rel="stylesheet"
      href="https://fonts.googleapis.com/css?family=Sofia"
    />

    <link rel="stylesheet" href="styles.css" />

    
  </head>
  <body id="mainBody" >
    <div class="container-fluid">
       <!--Nav Bar-->
       <?php
     require_once('layouts/navbar.php');
     ?>

    </div>
  </body>

  <script>
    
$( document ).ready(function() {
  var hallid=getHallId();
  console.log(hallid);

  $.ajax({
        url: 'includes/get_result.php',
        type: 'POST',
        data:  {"REQUEST_TYPE":"GET_HALL_DESC","HALL_ID":hallid},
        success: function(response){     
          console.log(response);
        var jobj=  JSON.parse(response);
    

         createDynamicUI(jobj.hallPrice,jobj.hallMainImage,jobj.amiIconsArr,jobj.amiDescArr,jobj.subImgArr,jobj.ratingStarsArr,jobj.usernameArr,jobj.reviewsArr,jobj.hallDName, jobj.hallDAddress);

   }
  });

});


    var hallid; //global variable to script
    function changeImage() {
      mainImage.src = this.src;
    }
    function bookNow() {
      window.location.href = "confirmbooking.php?hallid=" + hallid;
    }

    function bodyLoaded() {
    
    //  console.log(hallid);
      createDynamicUI();
    }

    function getHallId(){
      const queryString = window.location.search; //returns part after ?
      const urlParams = new URLSearchParams(queryString); //returns object that contains keys and valus
      hallid = urlParams.get("hallid"); //returns value of key
      return hallid;
    }

    function createDynamicUI(hallDprice,hallMainImage,amiIconsArr,amiDescArr,subImgArr,ratingStarsArr,usernameArr,reviewsArr, hallDName, hallDAddress) {
   
      var containerDiv = document.createElement("div");
      containerDiv.classList.add("container-fluid");
      var rowDiv = document.createElement("div");
      rowDiv.classList.add("row");
      //Image Coloumn
      var imgCol = document.createElement("div");
      imgCol.classList.add("col");
      imgCol.style.textAlign = "center";
      var mainImage = document.createElement("img");
      mainImage.src = "images/"+hallMainImage;
      mainImage.style.width = "500px";
      mainImage.style.height = "400px";
      mainImage.style.marginTop = "20px";
      mainImage.id = "mainImage";
      imgCol.appendChild(mainImage);

      //small images
      var subImageDiv = document.createElement("div");
      subImageDiv.classList.add("flex-container");

      for (var i = 0; i < subImgArr.length; i++) {
        var subImage = document.createElement("div");
        subImage.classList.add("flex-items");
        subImage.style.marginLeft = "35px";
        var subImage1 = document.createElement("img");
        subImage1.src = "images/" + subImgArr[i];
        subImage1.classList.add("img-small-image");
        subImage1.addEventListener("click", changeImage);
        subImage.appendChild(subImage1);
        subImageDiv.appendChild(subImage);
      }

      imgCol.appendChild(subImageDiv);
      rowDiv.appendChild(imgCol);

      //Description column
      var descCol = document.createElement("div");
      descCol.classList.add("col");
      var headingFlex = document.createElement("div");
      headingFlex.classList.add("flex-container");
      var head1 = document.createElement("div");
      head1.classList.add("flex-items");
      var hallName = document.createElement("h2");
      hallName.innerHTML = hallDName;
      var hallAddress = document.createElement("p");
      hallAddress.innerHTML =  hallDAddress;
      var hallPrice = document.createElement("h4");
      hallPrice.style.color="green";
      hallPrice.innerHTML = "Rs. "+ hallDprice +" /-";

      head1.appendChild(hallName);
      head1.appendChild(hallAddress);
      head1.appendChild(hallPrice);
      headingFlex.appendChild(head1);

      var head2 = document.createElement("div");
      head2.classList.add("flex-items");
      var bookNowButton = document.createElement("button");
      bookNowButton.innerHTML = "Book Now";
      bookNowButton.classList.add("btn");
      bookNowButton.classList.add("btn-success");
      bookNowButton.addEventListener("click", bookNow);
      head2.style.marginLeft = "45%";
      head2.appendChild(bookNowButton);
      headingFlex.appendChild(head2);
      descCol.appendChild(headingFlex);

      //Aminities Div
      var aminityDiv = document.createElement("div");
      var aminityPara = document.createElement("p");
      aminityPara.style =
        "font-weight: bold; color: chocolate; font-size: 20px";
      aminityPara.innerHTML = "Aminities";
      aminityDiv.appendChild(aminityPara);
      descCol.appendChild(aminityDiv);
      var aminityIconDiv = document.createElement("div");
      aminityIconDiv.classList.add("flex-container");
      aminityIconDiv.style.flexWrap = "wrap";
      for (var i = 0; i < amiIconsArr.length; i++) {
        aminityIconDiv.id = "amiIcons";
        var aminityIconItem = document.createElement("div");
        aminityIconItem.classList.add("flex-items");
        var amiIcon = document.createElement("img");
        amiIcon.src = "images/" + amiIconsArr[i];
        amiIcon.classList.add("img-icon");
        var amiDesc = document.createElement("p");
        amiDesc.classList.add("aminities");
        amiDesc.innerHTML = amiDescArr[i];
        aminityIconItem.appendChild(amiIcon);
        aminityIconItem.appendChild(amiDesc);
        aminityIconDiv.appendChild(aminityIconItem);
      }
      descCol.appendChild(aminityIconDiv);

      //Ratings
      var ratingsDiv = document.createElement("div");
      ratingsDiv.classList.add("flex-container");
      var ratingText = document.createElement("div");
      ratingText.classList.add("flex-items");
      ratingText.innerHTML = "Ratings:";
      ratingText.style = "font-weight: bold; color: chocolate; font-size: 20px";
      var ratingStars = document.createElement("div");
      ratingStars.classList.add("flex-items");
      ratingStars.innerHTML = ratingStarsArr;
      ratingsDiv.appendChild(ratingText);
      ratingsDiv.appendChild(ratingStars);
      descCol.appendChild(ratingsDiv);

      //User Reviews
      var UserReviesDiv = document.createElement("div");
      UserReviesDiv.style =
        "font-weight: bold; color: chocolate; font-size: 20px";
      UserReviesDiv.innerHTML = "User Reviews";
      descCol.appendChild(UserReviesDiv);

      //Actual Reviews
      var reviewsDiv = document.createElement("div");
      reviewsDiv.classList.add("flex-container");

      for (var i = 0; i < reviewsArr.length; i++) {
        var userIconDiv = document.createElement("div");
        userIconDiv.classList.add("flex-items");
        var userIcon = document.createElement("img");
        userIcon.src = "images/user.png";
        userIcon.classList.add("img-user-icon");
        var userReviewsDiv = document.createElement("div");
        userReviewsDiv.style.width = "80%";
        userReviewsDiv.classList.add("flex-items");
        var userReview = document.createElement("p");
        userReview.style.textAlign = "left";
        var username =
          "<span class='reviewClass'>" + usernameArr[i] + "</span> <br>";
        var review = reviewsArr[i];
        userReview.innerHTML = username + review;
        userIconDiv.appendChild(userIcon);
        reviewsDiv.appendChild(userIconDiv);
        userReviewsDiv.appendChild(userReview);
        reviewsDiv.appendChild(userReviewsDiv);
      }

      descCol.appendChild(reviewsDiv);

      rowDiv.appendChild(descCol);
      containerDiv.appendChild(rowDiv);
      mainBody.appendChild(containerDiv);
    }
  </script>
</html>
